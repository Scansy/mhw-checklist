# mhw-checklist
This website is a collaboration between me and @0Thomas1

# Overview
A simple website to make a checklist or to-do list of weapons in Monster Hunter World!  
You can keep track your desired weapons and see what materials are needed  
Features:
- Account systems to save your list
- Full access to all Monster Hunter World weapons through the MHW API
- See total materials needed for your weapons

# Stacks 
- Node js
- Bootstrap
- MongoDB

# Installation
- run ```npm install``` to install dependencies
- run ```npm start```  to host locally
